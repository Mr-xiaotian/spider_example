
    var config = {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "adsl.proxy.acedata.cloud",
                    port: parseInt(30005)
                },
                bypassList: ["localhost"]
            }
        };
    
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "4c41328e",
                    password: "ab0ab20f4c744240815604198c74eac4"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ["blocking"]
    );
    